@echo off
chcp 65001 >nul
title DynastyVault
cd /d "%~dp0"
echo ==== DynastyVault laptop pe shuru ho raha hai ====
py -3.11 -V >nul 2>nul && (set "PY=py -3.11" & goto havepy)
python --version >nul 2>nul && (set "PY=python" & goto havepy)
goto nopython
:havepy
if not exist ".venv\Scripts\python.exe" echo Pehli baar setup ho raha hai...
if not exist ".venv\Scripts\python.exe" %PY% -m venv .venv
set "VPY=.venv\Scripts\python.exe"
if not exist "%VPY%" goto nopython
if exist ".venv\voice_ok.txt" goto run
echo AI voice model install ho raha hai - pehli baar 10 se 30 minute lag sakte hain, kuch GB download hoga...
"%VPY%" -m pip install --upgrade pip
where nvidia-smi >nul 2>nul && echo NVIDIA graphics card mila - GPU wala version install ho raha hai...
where nvidia-smi >nul 2>nul && "%VPY%" -m pip install torch==2.6.0 torchaudio==2.6.0 --index-url https://download.pytorch.org/whl/cu124
"%VPY%" -m pip install -r requirements.txt && echo ok> ".venv\voice_ok.txt"
if not exist ".venv\voice_ok.txt" echo Voice model install nahi hua - website phir bhi chalegi, cloning baad mein.
:run
echo.
echo Website khul rahi hai: http://localhost:8765
echo Yeh kaali window KHULI rakho. Band karne ke liye Ctrl+C dabao.
"%VPY%" voice_server.py
pause
exit /b 0
:nopython
echo Python nahi mila.
echo python.org/downloads se Python 3.11 install karo, aur install ke time "Add python.exe to PATH" pe tick zaroor lagana.
start "" https://www.python.org/downloads/release/python-3119/
pause
