#!/bin/bash
# DynastyVault — Mac / Linux starter
cd "$(dirname "$0")" || exit 1
echo "==== DynastyVault laptop pe shuru ho raha hai ===="
PY="$(command -v python3.11 || command -v python3)"
if [ -z "$PY" ]; then
  echo "Python nahi mila. python.org/downloads se Python 3.11 install karo, phir yeh file dobara kholo."
  open "https://www.python.org/downloads/release/python-3119/" 2>/dev/null
  read -r -p "Enter dabao..."; exit 1
fi
[ -x .venv/bin/python ] || { echo "Pehli baar setup ho raha hai..."; "$PY" -m venv .venv; }
if [ ! -f .venv/voice_ok.txt ]; then
  echo "AI voice model install ho raha hai — pehli baar 10–30 minute, kuch GB download hoga..."
  .venv/bin/python -m pip install --upgrade pip
  if .venv/bin/python -m pip install -r requirements.txt; then echo ok > .venv/voice_ok.txt; else echo "Voice model install nahi hua — website phir bhi chalegi."; fi
fi
echo ""
echo "Website khul rahi hai: http://localhost:8765  (yeh window khuli rakho · band karne ke liye Ctrl+C)"
.venv/bin/python voice_server.py
