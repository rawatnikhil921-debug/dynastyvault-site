#!/usr/bin/env python3
"""DynastyVault on your laptop — website + free local AI voice cloning (Chatterbox Multilingual, MIT)
+ free local AI "full body" painting for the reunion portrait (Stable Diffusion inpainting).

Run:  python voice_server.py        → opens http://localhost:8765
The website works even if the voice model is not installed; cloning lights up once it loads.
Everything stays on this computer: recordings are never uploaded anywhere.
"""
import base64, io, json, mimetypes, os, re, sys, tempfile, threading, time, wave, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if (ROOT / "website" / "app.html").is_file(): ROOT = ROOT / "website"   # the website lives in website/ (same folder you upload to Netlify)
PORT = int(os.environ.get("DV_PORT", "8765"))
SITE_URL = "https://rawatnikhil921-debug.github.io/dynastyvault-site/app.html"
HOST = os.environ.get("DV_HOST", "127.0.0.1")
FAKE = os.environ.get("DV_FAKE_MODEL") == "1"        # for testing without the real model
LANGS = ["ar", "da", "de", "el", "en", "es", "fi", "fr", "he", "hi", "it", "ja", "ko", "ms", "nl", "no", "pl", "pt", "ru", "sv", "sw", "tr", "zh"]
MAX_TEXT = 2500

state = {"model": None, "error": None, "device": "cpu", "loading": True, "sr": 24000, "started": time.time()}
gen_lock = threading.Lock()

# ---- reunion portrait: AI paints bodies / chairs below the real faces (loaded only when first used) ----
PAINT_MODELS = [m for m in [os.environ.get("DV_PAINT_MODEL"), "Lykon/dreamshaper-8-inpainting", "stable-diffusion-v1-5/stable-diffusion-inpainting"] if m]
paint = {"pipe": None, "loading": False, "error": None, "model": None, "device": None}
paint_lock = threading.Lock()


def load_paint():
    if FAKE:
        time.sleep(1.0); paint.update(pipe="fake", model="fake", device="test", loading=False); log("Fake paint model ready (test mode)."); return
    try:
        import torch
        from diffusers import StableDiffusionInpaintPipeline
        dev = "cuda" if torch.cuda.is_available() else ("mps" if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available() else "cpu")
        dtype = torch.float16 if dev == "cuda" else torch.float32
        log(f"Loading the portrait painter on {dev.upper()} … (first time downloads about 2 GB)")
        pipe, last, used = None, None, None
        for repo in PAINT_MODELS:
            for variant in ("fp16", None):
                try:
                    kw = dict(torch_dtype=dtype, safety_checker=None, requires_safety_checker=False)
                    if variant: kw["variant"] = variant
                    pipe = StableDiffusionInpaintPipeline.from_pretrained(repo, **kw); used = repo; break
                except Exception as e:
                    last = e; pipe = None
            if pipe is not None: break
        if pipe is None: raise last or RuntimeError("no model")
        try:
            from diffusers import DPMSolverMultistepScheduler
            pipe.scheduler = DPMSolverMultistepScheduler.from_config(pipe.scheduler.config, use_karras_sigmas=True)
        except Exception: pass
        pipe = pipe.to(dev)
        if dev != "cuda":
            try: pipe.enable_attention_slicing()
            except Exception: pass
        paint.update(pipe=pipe, model=used, device=dev)
        log(f"✓ Portrait painter is ready ({used}).")
    except ModuleNotFoundError as e:
        paint["error"] = f"Painter not installed ({e}). Delete the .venv folder and run the START file again."
        log(paint["error"])
    except Exception as e:
        paint["error"] = f"{type(e).__name__}: {e}"
        log("Portrait painter failed to load:", paint["error"])
    finally:
        paint["loading"] = False


def paint_body(img_b64, mask_b64, prompt, negative, seed, steps=None):
    from PIL import Image, ImageFilter, ImageEnhance
    img = Image.open(io.BytesIO(base64.b64decode(img_b64))).convert("RGB")
    mask = Image.open(io.BytesIO(base64.b64decode(mask_b64))).convert("L").resize(img.size)
    W, H = img.size
    # work only on the family (mask area + their heads for context) so the AI paints at full detail
    box = mask.point(lambda v: 255 if v > 16 else 0).getbbox() or (0, 0, W, H)
    bw, bh = box[2] - box[0], box[3] - box[1]
    x0, x1 = max(0, box[0] - int(bw * 0.12)), min(W, box[2] + int(bw * 0.12))
    y0, y1 = max(0, box[1] - int(bh * 0.35)), min(H, box[3] + int(bh * 0.05))
    ci, cm = img.crop((x0, y0, x1, y1)), mask.crop((x0, y0, x1, y1)); cw, ch = ci.size
    if paint["pipe"] == "fake":
        time.sleep(1.5)
        out = ci.filter(ImageFilter.GaussianBlur(18)); out = ImageEnhance.Color(out).enhance(0.4)
        out = Image.blend(out, Image.new("RGB", ci.size, (120, 90, 160)), 0.35)
    else:
        import torch
        dev = paint["device"]; big = 1024 if dev == "cuda" else 768
        s = min(2.0, big / max(cw, ch)); w8, h8 = max(64, int(cw * s) // 8 * 8), max(64, int(ch * s) // 8 * 8)
        g = torch.Generator(device="cpu").manual_seed(int(seed) % (2 ** 31))
        res = paint["pipe"](prompt=prompt, negative_prompt=negative, image=ci.resize((w8, h8), Image.LANCZOS), mask_image=cm.resize((w8, h8), Image.BILINEAR),
                            width=w8, height=h8, num_inference_steps=int(steps or (28 if dev == "cuda" else 22)), guidance_scale=7.0, generator=g).images[0]
        out = res.resize((cw, ch), Image.LANCZOS)
        if s < 1: out = out.filter(ImageFilter.UnsharpMask(radius=2, percent=60, threshold=2))
    full = img.copy(); full.paste(out, (x0, y0))
    final = Image.composite(full, img, mask.filter(ImageFilter.GaussianBlur(3)))   # outside the mask stays exactly the real photo
    buf = io.BytesIO(); final.save(buf, "PNG"); return buf.getvalue()


def log(*a):
    print("[DynastyVault]", *a, flush=True)


def load_model():
    if FAKE:
        state.update(model="fake", loading=False, device="test"); log("Fake voice model ready (test mode)."); return
    try:
        import torch
        dev = "cuda" if torch.cuda.is_available() else ("mps" if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available() else "cpu")
        state["device"] = dev
        if dev != "cuda":   # checkpoints were saved on GPU — map them to this device
            _orig = torch.load
            def _load(*a, **k):
                k.setdefault("map_location", torch.device(dev)); return _orig(*a, **k)
            torch.load = _load
        log(f"Loading Chatterbox Multilingual on {dev.upper()} … (first run downloads the model, a few GB)")
        from chatterbox.mtl_tts import ChatterboxMultilingualTTS
        m = ChatterboxMultilingualTTS.from_pretrained(device=dev)
        state.update(model=m, sr=getattr(m, "sr", 24000))
        log("✓ Voice cloning is ready.")
    except ModuleNotFoundError as e:
        state["error"] = "Voice model not installed yet (pip install chatterbox-tts). The website still works."
        log(state["error"], f"({e})")
    except Exception as e:
        state["error"] = f"{type(e).__name__}: {e}"
        log("Voice model failed to load:", state["error"])
    finally:
        state["loading"] = False


def split_text(text):
    parts = re.split(r"(?<=[.!?।॥])\s+|\n+", text.strip())
    out, cur = [], ""
    for p in (x.strip() for x in parts if x.strip()):
        if len(cur) + len(p) < 240: cur = (cur + " " + p).strip()
        else:
            if cur: out.append(cur)
            while len(p) > 280:   # very long sentence: cut at a comma or space
                cut = max(p.rfind(",", 0, 260), p.rfind(" ", 0, 260)) or 260
                out.append(p[:cut].strip()); p = p[cut:].lstrip(", ")
            cur = p
    if cur: out.append(cur)
    return out


def wav_bytes(samples, sr):
    import array
    pcm = array.array("h", (max(-32767, min(32767, int(s * 32767))) for s in samples))
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes(pcm.tobytes())
    return buf.getvalue()


def synthesize(text, lang, ref_path):
    chunks = split_text(text)
    if state["model"] == "fake":
        import math
        sr = 24000; out = []
        for c in chunks: out += [0.2 * math.sin(2 * math.pi * 180 * i / sr) for i in range(int(sr * 0.6))] + [0.0] * int(sr * 0.1)
        return wav_bytes(out, sr), len(chunks)
    import torch
    sr = state["sr"]; pieces = []
    gap = torch.zeros(int(sr * 0.22))
    for c in chunks:
        wav = state["model"].generate(c, language_id=lang, audio_prompt_path=ref_path)
        pieces.append(wav.detach().float().cpu().reshape(-1)); pieces.append(gap)
    allw = torch.cat(pieces) if pieces else torch.zeros(1)
    peak = float(allw.abs().max()) or 1.0
    if peak > 1.0: allw = allw / peak
    return wav_bytes(allw.tolist(), sr), len(chunks)


class Handler(BaseHTTPRequestHandler):
    server_version = "DynastyVault/1.0"

    def log_message(self, fmt, *args):
        if "/api/" in (args[0] if args else ""): log(fmt % args)

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")

    def _send(self, code, body, ctype="application/json"):
        if isinstance(body, (dict, list)): body = json.dumps(body).encode()
        elif isinstance(body, str): body = body.encode()
        self.send_response(code); self._cors()
        self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204); self._cors(); self.end_headers()

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/api/health":
            return self._send(200, {"ok": True, "app": "dynastyvault", "clone": state["model"] is not None, "loading": state["loading"],
                                    "device": state["device"], "error": state["error"], "languages": LANGS,
                                    "paint": {"ready": paint["pipe"] is not None, "loading": paint["loading"], "error": paint["error"], "device": paint["device"], "model": paint["model"]}})
        rel = "index.html" if path in ("/", "") else path.lstrip("/")
        f = (ROOT / rel).resolve()
        if ROOT not in f.parents and f != ROOT / "index.html" or not f.is_file() or f.suffix in (".py", ".bat", ".command", ".txt"):
            return self._send(404, {"error": "not found"})
        self._send(200, f.read_bytes(), mimetypes.guess_type(str(f))[0] or "application/octet-stream")

    def do_POST(self):
        if self.path.split("?")[0] == "/api/paint": return self._paint()
        if self.path.split("?")[0] != "/api/clone": return self._send(404, {"error": "not found"})
        try:
            n = int(self.headers.get("Content-Length", "0"))
            if n <= 0 or n > 30 * 1024 * 1024: return self._send(413, {"error": "Request too large (keep the reference under ~20 s)."})
            req = json.loads(self.rfile.read(n) or b"{}")
            text = str(req.get("text", "")).strip()[:MAX_TEXT]; lang = str(req.get("language", "en")).lower()[:5]
            ref = str(req.get("reference", ""))
            if not text: return self._send(400, {"error": "No text to speak."})
            if lang not in LANGS: return self._send(400, {"error": f"Language '{lang}' is not supported by the voice model."})
            m = re.match(r"^data:audio/[\w.+-]+;base64,(.+)$", ref, re.S)
            if not m: return self._send(400, {"error": "Reference recording missing — record or upload a voice sample first."})
            if state["model"] is None:
                return self._send(503, {"error": "Voice model is still loading." if state["loading"] else (state["error"] or "Voice model not available.")})
            audio = base64.b64decode(m.group(1))
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tf: tf.write(audio); ref_path = tf.name
            try:
                t0 = time.time()
                with gen_lock: data, parts = synthesize(text, lang, ref_path)
                log(f"Cloned {len(text)} chars in {lang} · {parts} part(s) · {time.time() - t0:.1f}s")
            finally:
                try: os.unlink(ref_path)
                except OSError: pass
            self._send(200, data, "audio/wav")
        except Exception as e:
            log("Clone failed:", type(e).__name__, e)
            self._send(500, {"error": f"{type(e).__name__}: {e}"})


def _paint_handler(self):
    try:
        n = int(self.headers.get("Content-Length", "0"))
        if n <= 0 or n > 40 * 1024 * 1024: return self._send(413, {"error": "Picture too large."})
        req = json.loads(self.rfile.read(n) or b"{}")
        mi = re.match(r"^data:image/[\w.+-]+;base64,(.+)$", str(req.get("image", "")), re.S)
        mm = re.match(r"^data:image/[\w.+-]+;base64,(.+)$", str(req.get("mask", "")), re.S)
        if not mi or not mm: return self._send(400, {"error": "Picture or mask missing."})
        if paint["pipe"] is None:
            if not paint["loading"] and (paint["error"] is None or req.get("retry")):
                paint.update(loading=True, error=None); threading.Thread(target=load_paint, daemon=True).start()
            if paint["loading"]: return self._send(503, {"loading": True})
            return self._send(503, {"loading": False, "error": paint["error"] or "Painter not available."})
        t0 = time.time()
        with paint_lock:
            data = paint_body(mi.group(1), mm.group(1), str(req.get("prompt", ""))[:600], str(req.get("negative", ""))[:600], req.get("seed", 1), req.get("steps"))
        log(f"Painted reunion portrait in {time.time() - t0:.1f}s")
        self._send(200, data, "image/png")
    except Exception as e:
        log("Paint failed:", type(e).__name__, e)
        self._send(500, {"error": f"{type(e).__name__}: {e}"})


Handler._paint = _paint_handler


def main():
    threading.Thread(target=load_model, daemon=True).start()
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    url = f"http://localhost:{PORT}"
    log(f"Website running at {url}  (keep this window open · Ctrl+C to stop)")
    # with the website files next to this program open the local copy, otherwise open the online website
    # (the online site finds this voice engine at http://localhost:8765 by itself)
    page = url + "/app.html" if (ROOT / "app.html").is_file() else os.environ.get("DV_SITE", SITE_URL)
    if os.environ.get("DV_NO_BROWSER") != "1": threading.Timer(1.2, lambda: webbrowser.open(page)).start()
    try: srv.serve_forever()
    except KeyboardInterrupt: log("Stopped.")


if __name__ == "__main__":
    main()
